package edu.sharif.ce.ce244.seafight.presentation.board;

import edu.sharif.ce.ce244.seafight.model.Coordinate;
import edu.sharif.ce.ce244.seafight.model.CursorType;
import edu.sharif.ce.ce244.seafight.model.Human;
import edu.sharif.ce.ce244.seafight.model.Ship;
import edu.sharif.ce.ce244.seafight.presentation.SeaFight;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/**
 * Implements special features of player's gameboard.
 *
 * @author Kallio, Leisma, Tammivuori
 * @version 220503
 */
public class HumanBoard extends Gameboard {

    /**
     * gameboard's owner
     */
    private Human player;


    /**
     * Parameterized constructor. Implements the player's gameboard and set new cursors
     *
     * @param player owner of the gameboard
     */
    public HumanBoard(Human player, SeaFight seaFight) {
        super(player, seaFight);
        this.player = player;
        defaultCursor = new Cursor(Cursor.DEFAULT_CURSOR);



        // listen to mouse right-clicks for rotating ships
        MyMouseAdapter rightClick = new MyMouseAdapter();

        // start by showing ship as mouse cursor
        currentCursor = ship1Cursor;
        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++) {
                buttonmatrix[i][j].addMouseListener(rightClick);
                buttonmatrix[i][j].setCursor(currentCursor);
            }
        changeCursor(CursorType.findByShipOrientation(player.getCurrentShip().getShipOrientation()));
    }

    /**
     * Internal class which implements mouselisteners
     *
     * @author Kallio, Leisma, Tammivuori
     * @version 220503
     */
    class MyMouseAdapter extends MouseAdapter {
        public void mousePressed(final MouseEvent e) {
            if ((e.getModifiers() & MouseEvent.BUTTON3_MASK) != 0) {
                Ship current = player.getCurrentShip();
                if (current != null) {
                    current.rotate();
                    changeCursor(CursorType.findByShipOrientation(current.getShipOrientation()));
                }
            }
        }
    }

    /**
     * Change cursor picture
     *
     * @param CursorType   enum
     */
    public void changeCursor(CursorType cursorType) {

        super.changeCursor(cursorType);


        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++) {
                buttonmatrix[i][j].setCursor(currentCursor);
            }

        repaint();
    }

    /**
     * places one player's ship to the gameboard.
     *
     * @param ship placing ship
     * @param xy   ship's place
     */
    protected void placeShip(Ship ship, Coordinate xy) {
        // after actually placing the ship in Gameboard ...
        super.placeShip(ship, xy);

        // ... visualize ships location on the Human players board
        String symbol = (" ");   // no symbol needed now
        Color color = Color.gray;  // new buttoncolor

        for (int i = 0; i < ship.getShipSize(); i++) {
            symbol = ("");
            buttonmatrixSetLabel(ship.getShipCoordinate(i), symbol, color);
        }
    }

    /**
     * places all player's ships to the gameboard.
     */
    public void placeShips() {
        // just left-click to place a ship
        // MyMouseListener does all
        // the work
    }
}



