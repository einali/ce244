package edu.sharif.ce.ce244.seafight.model;

/**
 * Created by Teaching on 10/23/2015.
 */
public enum OrientationType {
    North("North", 1), East("East", 2), South("South", 3), West("West", 4);

    String message;
    int code;
    CursorType cursorType;


    OrientationType(String message, int code) {
        this.message = message;
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public int getCode() {
        return code;
    }

    public static OrientationType findByCode(int code){
        for(OrientationType type:values()){
            if(code==type.getCode()){
                return type;
            }
        }
        return null;
    }

    public OrientationType rotate(){
        int code=getCode();
        if(code>= OrientationType.values().length){
            code=1;
        }else {
            code++;
        }

        return findByCode(code);
    }
}
