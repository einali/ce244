package edu.sharif.ce.ce244.seafight.presentation.board;

import edu.sharif.ce.ce244.seafight.model.Coordinate;
import edu.sharif.ce.ce244.seafight.model.Machine;
import edu.sharif.ce.ce244.seafight.model.OrientationType;
import edu.sharif.ce.ce244.seafight.model.Ship;
import edu.sharif.ce.ce244.seafight.presentation.SeaFight;
import edu.sharif.ce.ce244.seafight.util.Utils;

/**
 * Implements special features of computer's gameboard
 * 
 * @author Kallio, Leisma, Tammivuori 
 * @version 220503
 */
public class MachineBoard extends Gameboard
{
    /**
     * record of ship names
     */
    private Ship[] shipNames = new Ship[10];



    /**
     * present cursor
     */

    /**
     * Parameterized constructor. Implements the computer's gameboard.
     * @param player owner of the gameboard
     */
    public MachineBoard(Machine player,SeaFight seaFight)
    {
        super(player, seaFight);



        // start by showing aiming rings as mouse cursor
        for (int i = 0; i < Gameboard.size; i++)
            for (int j = 0; j < Gameboard.size; j++) {
                buttonmatrix[i][j].setCursor(currentCursor);
            }
    }
    
    /**
     * Places randomly all computer's ships on the Gameboard
     */  
    public void placeShips() {
        int i = 0;
        Coordinate xy = new Coordinate();
        shipNames[i] = new Ship(4, OrientationType.findByCode(Utils.getRandom(4) + 1),seaFight);
  
        do{
            xy.setCoordinate(Utils.getRandom(Gameboard.size), Utils.getRandom(Gameboard.size));
        } while (mayIPlaceShip(shipNames[i], xy) == false);
        placeShip(shipNames[i], xy);

        i++;
        for (; i < 3; i++) {        
            shipNames[i] = new Ship(3,  OrientationType.findByCode(Utils.getRandom(4)+1),seaFight);
            do{
                xy.setCoordinate(Utils.getRandom(Gameboard.size), Utils.getRandom(Gameboard.size));
            } while (mayIPlaceShip(shipNames[i], xy) == false);
            placeShip(shipNames[i], xy);        
        }

        for (; i < 6; i++) {
            shipNames[i] = new Ship(2, OrientationType.findByCode(Utils.getRandom(4)+1),seaFight);
            do{
                xy.setCoordinate(Utils.getRandom(Gameboard.size), Utils.getRandom(Gameboard.size));
            } while (mayIPlaceShip(shipNames[i], xy) == false);
            placeShip(shipNames[i], xy);  
        }

        for (; i < 10; i++) {
            shipNames[i] = new Ship(1,OrientationType.findByCode( Utils.getRandom(4)+1),seaFight);
            do{
                xy.setCoordinate(Utils.getRandom(Gameboard.size), Utils.getRandom(Gameboard.size));
            } while (mayIPlaceShip(shipNames[i], xy) == false);
            placeShip(shipNames[i], xy);          
        }
     
    buttonmatrixCleanButtons();
    clearAllHitStatus();
            
    }


                
}

