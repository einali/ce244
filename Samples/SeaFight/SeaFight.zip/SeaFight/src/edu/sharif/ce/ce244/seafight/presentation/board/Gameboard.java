package edu.sharif.ce.ce244.seafight.presentation.board;

import edu.sharif.ce.ce244.seafight.model.*;
import edu.sharif.ce.ce244.seafight.presentation.SeaFight;
import edu.sharif.ce.ce244.seafight.util.Utils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Gameboard of the Sea Fight. Both player ja computer have his own board. This class
 * implements all common methods and arguments.
 *
 * @author Kallio, Leisma, Tammivuori
 * @version 220503
 */
public class Gameboard extends JLayeredPane {
    /**
     * dimensions of board (size * size)
     */
    public static final int size = 10;
    /**
     * for show messages
     */
    protected final SeaFight seaFight;

    /**
     * count ship squares, used when placing ships
     */
    protected int shipSquareCounter = 0;

    /**
     * tells if there is a ship in a square and what ship it is
     */
    protected Ship[][] ships = new Ship[size][size];

    /**
     * records square's hit status: 1=notShotAt, 2=miss, 3=hit, 4=sunk
     */
    protected int[][] hitStatus = new int[size][size];

    /**
     * gameboard owner
     */
    protected Player owner;

    /**
     * buttonpanel
     */
    protected JPanel board;

    /**
     * buttonmatrix
     */
    protected JButton[][] buttonmatrix;

    /**
     * coordinate table
     */
    protected Coordinate[] coordinates;

    protected Cursor currentCursor;


    /**
     * cursor when it is on the board
     */
    protected static Cursor shootCursor;
    /**
     * default cursor
     */
    protected static Cursor defaultCursor;

    /**
     * cursor when it is on the board, cursor's direction is north
     */
    protected static Cursor ship1Cursor;
    /**
     * cursor when it is on the board, cursor's direction is east
     */
    protected static Cursor ship2Cursor;
    /**
     * cursor when it is on the board, cursor's direction is south
     */
    protected static Cursor ship3Cursor;
    /**
     * cursor when it is on the board, cursor's direction is west
     */
    protected static Cursor ship4Cursor;


    /**
     * cursor's image. Ship's direction is north. Used when created a new cursor
     */
    private Image ship1Image;
    /**
     * cursor's image. Ship's direction is east. Used when created a new cursor
     */
    private Image ship2Image;
    /**
     * cursor's image. Ship's direction is south. Used when created a new cursor
     */
    private Image ship3Image;
    /**
     * cursor's image. Ship's direction is west. Used when created a new cursor
     */
    private Image ship4Image;

    /**
     * cursor's image when it is on the board. Used when created a new cursor
     */
    private Image shootImage;


    /**
     * Parameterized constructor. Implements the gameboard.
     *
     * @param owner owner of the gameboard
     */
    public Gameboard(Player owner, SeaFight seaFight) {


        defaultCursor = new Cursor(Cursor.DEFAULT_CURSOR);


        try {
            Toolkit tk = Toolkit.getDefaultToolkit();

            // show aiming rings as mouse cursor when shooting
            shootImage = Utils.getImage("target3.gif");
            shootCursor = tk.createCustomCursor(shootImage,
                    new Point(16, 16), "Shoot");
            currentCursor = shootCursor;

            // create a custom cursor which represents the the
            // current ship size and orientation (from Human)
            // cursor sizes 32x32, 64x64, ... px
            ship1Image = Utils.getImage("shipNorth.gif"); //64x64
            ship1Cursor = tk.createCustomCursor(ship1Image,
                    new Point(16, 31), "ShipNorth"); // damn Windows and only 32x32 cursors, grrrrr....

            ship2Image = Utils.getImage("shipEast.gif"); //64x64
            ship2Cursor = tk.createCustomCursor(ship2Image,
                    new Point(0, 15), "ShipEast");
            // new Point(0,32), "ShipEast");

            ship3Image = Utils.getImage("shipSouth.gif"); //64x64
            ship3Cursor = tk.createCustomCursor(ship3Image,
                    new Point(15, 0), "ShipSouth");
            // new Point(32,0), "ShipSouth");

            ship4Image = Utils.getImage("shipWest.gif"); //64x64
            ship4Cursor = tk.createCustomCursor(ship4Image,
                    new Point(31, 16), "ShipWest");
            // new Point(63,32), "ShipWest");
        } catch (Exception e) {
            System.out.println("Could not retrieve custom cursor images.");
            ship1Cursor = defaultCursor;
        }


        // set the player for this board
        this.owner = owner;

        this.seaFight = seaFight;
        // initialize hitStatus matrix
        clearAllHitStatus();

        // prepare to lay out additional Components
        // from deriving classes
        setLayout(new BorderLayout());

        // initialize board for buttonmatrix
        board = new JPanel();
        board.setLayout(new GridLayout(size, size));

        buttonmatrix = new JButton[size][size];
        MyButtonListener listener = new MyButtonListener();

        // players board will be blue   
        Color color = new Color(0, 154, 214);

        // add Listeners to squares
        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++) {
                buttonmatrix[i][j] = new JButton("    ");
                buttonmatrix[i][j].addActionListener(listener);
                buttonmatrixSetLabel(i, j, "    ", color);
            }

        // layout buttons on the board
        for (int k = 0; k < size; k++)
            for (int m = 0; m < size; m++)
                board.add(buttonmatrix[m][k]);

        // add the created buttonmatrix to the actual Gameboard
        add(board);
    }

    /**
     * Internal class which implements buttonlisteners
     *
     * @author Kallio, Leisma, Tammivuori
     * @version 220503
     */
    class MyButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent buttonClick) {
            Object object = buttonClick.getSource();
            Coordinate xy = new Coordinate(-1, -1);

            rows:
            for (int i = 0; i < size; i++)
                cols:for (int j = 0; j < size; j++) {
                    if (object == buttonmatrix[i][j]) {
                        xy.setCoordinate(i, j);

                        // only Human players call the buttons
                        if (!seaFight.getPlayingGame()) {
                            if (getGameboardOwner() instanceof Human) {
                                Ship current = owner.getCurrentShip();

                                if ((current != null) && mayIPlaceShip(current, xy)) {
                                    seaFight.showMessage("Placed ship at " +
                                            xy.getX() + " " + xy.getY() + "\n");
                                    seaFight.showOrientation("North");  // North is the default Ship
                                    // orientation for new Ships
                                    placeShip(current, xy);

                                    if (owner.setCurrentShip(getGameboard()) == false &&
                                            !seaFight.getPlayingGame()) {   // human has placed all Ships
                                        seaFight.getMachineBoard().placeShips();   // place computers Ships
                                        seaFight.setPlayingGame(true);            // switch to Game mode
                                        seaFight.setShipPanelVisible(); // hide placing info Panel
                                    }
                                }
                            } else {
                                seaFight.showMessage("Can't place ship " +
                                        "on the opponents board\n");
                            }
                        } else if (seaFight.getPlayingGame()) {
                            if (getGameboardOwner() instanceof Machine) {
                                if (hitStatus[xy.getX()][xy.getY()] == 1) {
                                    shoot(xy);
                                    Human.turn = false;

                                    // play machines turn
                                    if (seaFight.getPlayingGame()) {
                                        seaFight.makeOpponentPlay();
                                        Human.turn = true;
                                    }
                                    // end machines turn

                                    // check if we have a winner
                                    // status 4=sunk
                                    if (seaFight.getHumanBoard().getStatusCount(4) > 19) { // 4,3,3,2,2,2,1,1,1,1 Ships
                                        seaFight.showMessage("Computer wins.");   // =20 squares under Ships
                                        seaFight.getMachineBoard().buttonmatrixShowShips();
                                        seaFight.winner = "Computer wins.";
                                        seaFight.setGameOver();
                                    } else if (seaFight.getMachineBoard().getStatusCount(4) > 19) {
                                        seaFight.showMessage("You win !!!!!");
                                        seaFight.getHumanBoard().buttonmatrixShowShips();
                                        seaFight.setWinner("You win!");
                                        seaFight.setGameOver();
                                    }

                                } else
                                    seaFight.showMessage("Can't shoot at" +
                                            "Place where you are already shoot at\n");

                            } else {
                                seaFight.showMessage("Can't shoot at " +
                                        "your own board\n");
                                Human.turn = true;
                            }

                        }

                        break rows; // stop loop when coordinate found
                    }
                }

        }

    }

    /**
     * Returns owner of the gameboard
     *
     * @return gameboard's owner
     */
    protected Player getGameboardOwner() {
        return owner;
    }

    /**
     * Returns gameboard which call this method
     *
     * @return this gameboard
     */
    protected Gameboard getGameboard() {
        return this;
    }

    /**
     * Checks is given coordinate on the gameboard
     *
     * @param x x coordinate
     * @param y y coordinate
     * @return true if coordinate is on the board, else returns false
     */
    public boolean isSquareOnBoard(int x, int y) {
        if ((x < 0 || x > this.size - 1) || (y < 0 || y > this.size - 1))
            return false;
        return true;
    }

    /**
     * Sets status of surrounding squares to be missed,
     * so that ships won't get placed right next to each other
     *
     * @param ship ship, which is sunk
     */
    protected void setSurroundingSquares(Ship ship) {
        Coordinate tmp;  // surrounding square
        Coordinate tmp2; // ships square
        Color color = new Color(142, 193, 228); //light blue

        for (int i = 0; i < ship.getShipSize(); i++) { // get ship's next square

            tmp2 = new Coordinate(ship.getShipCoordinate(i));

            // verify and set surrounding squares
            for (int k = -1; k < 2; k++)
                for (int j = -1; j < 2; j++) {
                    tmp = new Coordinate(tmp2);
                    if (isSquareOnBoard(tmp.getX() + (k), tmp.getY() + (j)))
                        if (ships[tmp.getX() + (k)][tmp.getY() + (j)] == null) {
                            tmp.setCoordinate((tmp.getX() + (k)), (tmp.getY() + (j)));
                            setSquareStatus(tmp, 2); //1=notShotAt, 2=miss, 3=hit, 4=sunk
                            buttonmatrixSetLabel(tmp, " . ", color);
                        }
                }
        }
    }

    /**
     * Checks that all coordinates are free and inside of board
     *
     * @param ship placing ship
     * @param xy   coordinate of place
     * @return true if ship is totally on the board, else returns false
     */
    protected boolean mayIPlaceShip(Ship ship, Coordinate xy) {

        // check gameboard bounds
        switch (ship.getShipOrientation()) {
            case North:
                if ((xy.getY() + 1) < ship.getShipSize()) {
                    return false;
                }
                break;
            case East:
                if ((this.size - xy.getX()) < ship.getShipSize()) {
                    return false;
                }
                break;
            case South:
                if ((this.size - xy.getY()) < ship.getShipSize()) {
                    return false;
                }
                break;
            case West:
                if ((xy.getX() + 1) < ship.getShipSize()) {
                    return false;
                }
                break;
        }


        // check for overlaps with other ships and their surrounding squares
        Coordinate tmp = new Coordinate(xy.getX(), xy.getY());


        switch (ship.getShipOrientation()) {
            case North:
                for (int i = 0; i < ship.getShipSize(); i++) {
                    tmp.setCoordinate(xy.getX(), xy.getY() - i);
                    if (getSquareStatus(tmp) == 2) // 1=free, 2=occupied or next to ship
                        return false;
                }
                break;
            case East:
                for (int i = 0; i < ship.getShipSize(); i++) {
                    tmp.setCoordinate(xy.getX() + i, xy.getY());
                    if (getSquareStatus(tmp) == 2) // 1=free, 2=occupied or next to ship
                        return false;
                }
                break;
            case South:
                for (int i = 0; i < ship.getShipSize(); i++) {
                    tmp.setCoordinate(xy.getX(), xy.getY() + i);
                    if (getSquareStatus(tmp) == 2) // 1=free, 2=occupied or next to ship
                        return false;
                }
                break;
            case West:
                for (int i = 0; i < ship.getShipSize(); i++) {
                    tmp.setCoordinate(xy.getX() - i, xy.getY());
                    if (getSquareStatus(tmp) == 2) // 1=free, 2=occupied or next to ship
                        return false;
                }
                break;
        }
        return true;
    }


    /**
     * Place one ship on the gameboard
     *
     * @param ship placing ship
     * @param xy   coordinate of place
     */
    protected void placeShip(Ship ship, Coordinate xy) {
        this.shipSquareCounter += ship.getShipSize();
        Coordinate tmp = new Coordinate(xy.getX(), xy.getY());
        ship.setShipCoordinate(0, xy);
        ships[xy.getX()][xy.getY()] = ship;
        setSquareStatus(tmp, 2);


        switch (ship.getShipOrientation()) {
            case North:
                for (int i = 1; i < ship.getShipSize(); i++) {
                    tmp.setCoordinate(xy.getX(), xy.getY() - i);
                    ship.setShipCoordinate(i, tmp);
                    ships[tmp.getX()][tmp.getY()] = ship;
                    setSquareStatus(tmp, 2);
                }

                break;
            case East:
                for (int i = 1; i < ship.getShipSize(); i++) {
                    tmp.setCoordinate(xy.getX() + i, xy.getY());
                    ship.setShipCoordinate(i, tmp);
                    ships[tmp.getX()][tmp.getY()] = ship;
                    setSquareStatus(tmp, 2);
                }

                break;
            case South:
                for (int i = 1; i < ship.getShipSize(); i++) {
                    tmp.setCoordinate(xy.getX(), xy.getY() + i);
                    ship.setShipCoordinate(i, tmp);
                    ships[tmp.getX()][tmp.getY()] = ship;
                    setSquareStatus(tmp, 2);
                }

                break;
            case West:
                for (int i = 1; i < ship.getShipSize(); i++) {
                    tmp.setCoordinate(xy.getX() - i, xy.getY());
                    ship.setShipCoordinate(i, tmp);
                    ships[tmp.getX()][tmp.getY()] = ship;
                    setSquareStatus(tmp, 2);
                }

                break;
        }


        // sets the surrounding squares to (2=occupied)
        // so that ships won't get placed right next to each other
        setSurroundingSquares(ship);
    }

    /**
     * Changes ships squares on gameboard to sunk status and
     * calls for surrounding squares to be set as missed
     *
     * @param ship sinked ship
     * @param xy   coordinate of place
     */
    protected void sinkWholeShip(Ship ship, Coordinate xy) {

        // set squares which the ship uses to sunk status
        for (int i = 0; i < ship.getShipSize(); i++) {
            setSquareStatus(ship.getShipCoordinate(i), 4);
            buttonmatrixSetLabel((ship.getShipCoordinate(i)), " X ",
                    Color.darkGray);  // X = sunk
        }
        // merkitse my�s laivan ymp�rysruudut k�ytetyiksi
        setSurroundingSquares(ship);
    }

    /**
     * Checks if there is a ship in the square
     *
     * @param xy coordinate of square's place
     * @return ship if it is on that square, else null
     */
    protected Ship shipInSquare(Coordinate xy) {
        if (ships[xy.getX()][xy.getY()] != null)
            return (ships[xy.getX()][xy.getY()]);
        return null;
    }

    /**
     * Shoot on a square
     *
     * @param xy coordinate of shootingplace
     * @return hit status: 1=notShotAt, 2=miss, 3=hit, 4=sunk
     */
    public int shoot(Coordinate xy) {
        boolean sunk = false;
        Color color = new Color(142, 193, 228); //light blue                      
        Ship target = null;
        if (getSquareStatus(xy) == 1) {
            target = shipInSquare(xy);
            if (target != null) {
                // change square status to hit
                setSquareStatus(xy, 3);
                target.setShipHitStatus(xy);
                buttonmatrixSetLabel(xy, " x ", Color.gray);

                // check sinking
                sunk = target.hasShipSunk();
                if (sunk) {
                    sinkWholeShip(target, xy);
                }
                if (owner instanceof Machine) { // Show messages only to Human player
                    if (sunk) {
                        seaFight.showMessage("Ship has sunk\n");
                    } else {
                        seaFight.showMessage("You hit a ship, but it didn't sink\n");
                    }
                }
            } else { // player missed
                // set square status to missed
                setSquareStatus(xy, 2);
                buttonmatrixSetLabel(xy, " . ", color);
                if (owner instanceof Machine) {
                    seaFight.showMessage("You missed!");
                }
            }
        }

        return getSquareStatus(xy);
    }

    /**
     * Change status of all squares to 1 = notShotAt before starting the game
     */
    public void clearAllHitStatus() {
        for (int k = 0; k < size; k++)
            for (int m = 0; m < size; m++)
                hitStatus[k][m] = 1;
    }

    /**
     * Set square status to given status
     *
     * @param xy     coordinate of square
     * @param status 1=notShotAt, 2=miss, 3=hit, 4=sunk
     */
    protected void setSquareStatus(Coordinate xy, int status) {
        hitStatus[xy.getX()][xy.getY()] = status;
    }

    /**
     * returns status of a square
     *
     * @param xy coordinate of square
     * @return status: 1=notShotAt, 2=miss, 3=hit, 4=sunk
     */
    public int getSquareStatus(Coordinate xy) {
        return hitStatus[xy.getX()][xy.getY()];
    }

    /**
     * Add a new symbol and color onto the button
     * <pre>
     *   gray = ship placed
     *   x and gray = hit
     *   . and light blue = missed
     *   X and dark gray = sunk
     * </pre>
     *
     * @param x      x coordinate
     * @param y      y coordinate
     * @param symbol the symbol of button
     * @param color  the color of button
     */
    protected void buttonmatrixSetLabel(int x, int y, String symbol, Color color) {
        buttonmatrix[x][y].setText(symbol);
        buttonmatrix[x][y].setBackground(color);
    }

    /**
     * Adds a new symbol and color onto the button
     * <pre>
     *   gray = ship placed
     *   x and gray = hit
     *   . and light blue = missed
     *   X and dark gray = sunk
     * </pre>
     *
     * @param Coordinate xy the place of button
     * @param String     symbol the symbol of button
     * @param Color      color the color of button
     */
    protected void buttonmatrixSetLabel(Coordinate xy, String symbol, Color color) {
        buttonmatrix[xy.getX()][xy.getY()].setText(symbol);
        buttonmatrix[xy.getX()][xy.getY()].setBackground(color);
    }

    /**
     * Show where ships were located
     */
    protected void buttonmatrixShowShips() {
        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++) {
                Coordinate yx = new Coordinate(i, j);
                if (shipInSquare(yx) != null)
                    if (hitStatus[i][j] == 1)  //1=notShotAt 2=missed 3=hit 4=sunk
                        buttonmatrixSetLabel(i, j, "     ", Color.gray);
            }
    }


    /**
     * Remove symbols from the buttons and set new backgroundcolor
     */
    public void buttonmatrixCleanButtons() {
        Color color = new Color(0, 154, 214); //blue
        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++)
                buttonmatrixSetLabel(i, j, "     ", color);
    }


    /**
     * Returns all free or not shot at coordinates of board. First coordinate in index 0 tells
     * how many free coordinates will be in the table. Free coordinates start from index 1.
     *
     * @return table of free coordinates
     */
    public Coordinate[] getFreeCoordinates() {
        int k = 1;
        Coordinate[] table = new Coordinate[size * size + 1];
        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++)
                if (hitStatus[i][j] == 1) { //1=notShotAt 2=missed 3=hit 4=sunk
                    table[k] = new Coordinate(i, j);
                    k++;
                }
        table[0] = new Coordinate(k - 1, k - 1);
        return (table);
    }


    /**
     * Returns a number of squares which have given status
     *
     * @param status 1=notShotAt, 2=miss, 3=hit, 4=sunk
     * @return a number of squares
     */
    public int getStatusCount(int status) {
        int count = 0;

        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++)
                if (hitStatus[i][j] == status) { //1=notShotAt 2=missed 3=hit 4=sunk
                    count++;
                }

        return count;
    }

    /**
     * Change cursor when placing ships
     *
     * @param CursorType
     */
    public void changeCursor(CursorType cursorType) {

        if (cursorType == null) {
            currentCursor = defaultCursor;
            return;

        }
        switch (cursorType) {
            case DefaultCursor:
                currentCursor = defaultCursor;
                break;
            case ShipCursorNorth:
                currentCursor = ship1Cursor;
                break;
            case ShipCursorEast:
                currentCursor = ship2Cursor;
                break;
            case ShipCursorSouth:
                currentCursor = ship3Cursor;
                break;
            case ShipCursorWest:
                currentCursor = ship4Cursor;
                break;
            case ShootCursor:
                currentCursor = shootCursor;
                break;
            default:
                currentCursor = defaultCursor;
        }

    }
}

