package edu.sharif.ce.ce244.seafight.model;

import edu.sharif.ce.ce244.seafight.presentation.DisplayContainer;
import edu.sharif.ce.ce244.seafight.presentation.board.Gameboard;
import edu.sharif.ce.ce244.seafight.presentation.board.HumanBoard;
import edu.sharif.ce.ce244.seafight.util.Utils;

/**
 * Takes care of computerplayers gameturns. Shoots human's gameboard. If a ship was hit, tries to
 * find rest of it.
 *
 * @author Kallio, Leisma, Tammivuori
 * @version (220503)
 */

public class Machine extends Player {
    protected boolean previousHitStatus = false;
    static Coordinate hunted2 = new Coordinate(-1, -1);
    static Coordinate hunted1 = new Coordinate(-1, -1);
    static int direction = 1;

    /**
     * Constructor for objects of class Machine. Initialise instance variables.
     */
    public Machine(DisplayContainer DisplayContainer,Game game) {
        this.name = "Computer";
        this.displayContainer = DisplayContainer;
        this.game=game;
    }

    /**
     * Sets player name.
     *
     * @param name player name is computer.
     */
    public void setPlayerName(String name) {
        this.name = name;
    }

    /**
     * Gets the name of a player.
     *
     * @return name reveals name of the player.
     */
    public String getPlayerName() {
        return this.name;
    }

    /**
     * Reveals the ship that is currenttly dealed with when placing ships by human.
     * Must return null, because computerplayer doesn't place ships by drag and drop.
     *
     * @return null because there is no ships for computer to place.
     */
    public Ship getCurrentShip() {
        return null;
    }

    /**
     * Sets currently dealed ship. Used when placing ships.
     *
     * @param board ships are placed on gameboard.
     * @return true computer sets ships randomly, false is used when human is also ready.
     */
    public boolean setCurrentShip(Gameboard board) {
        return true;
    }


    /**
     * Computerplayer plays one turn i.e. goes on finding shootable square on humanplayer's
     * gameboard until finds one and shoots at it. Status: 1=notShotAt, 2=miss, 3=hit, 4=sunk.
     *
     * @param board computer shoots at Humanboard.
     * @return status reveals if shooting was done succesfully = true, otherwise false.
     */
    public boolean playTurn(HumanBoard board) {
        // getFreeCoordinates
        Coordinate[] coord = new Coordinate[Gameboard.size * Gameboard.size];
        coord = board.getFreeCoordinates();
        int status = 0;
        if (coord[0].getX() != 1) {  // there is free squares             
            if (previousHitStatus == true)    // go on shooting the previously hit ship
                status = HuntEnemyShip(board);  // returns (1=notShotAt, 2=miss, 3=hit, 4=sunk)
            else {
                // set random target, no hit previous round
                // should not shoot on coord[0]
                // returns (1=notShotAt, 2=miss, 3=hit, 4=sunk)
                int randFree = (Utils.getRandom(coord[0].getX()) + 1);
                status = board.shoot(coord[randFree]);
                if (status == 3) {    // new hit!
                    previousHitStatus = true;
                    hunted1 = new Coordinate(coord[randFree].getX(), coord[randFree].getY());
                }
            }
            if (status == 4) { // 4 == sunk
                previousHitStatus = false;     // next round computer will shoot randomly
                hunted1 = new Coordinate(-1, -1); // default values
                hunted2 = new Coordinate(-1, -1);
                direction = 1;
            }
        } else { // no free coordinates --> game will end.
            game.setPlayingGame(false);
        }
        if (status != 1) {
            return true;  // 1 = not shot
        } else {
            return false;
        }
    }


    /**
     * Computer tries to find rest of the ship that has been shot before
     *
     * @param board computer shoots at Humanboard
     * @return stat status of the shot 1=notShotAt, 2=miss, 3=hit, 4=sunk
     */
    protected int HuntEnemyShip(HumanBoard board) {
        int stat = 0;

        // First direction is 1 == South
        a:
        if (direction == 1) {
            if (hunted2.getX() == -1) {  // -1 == default
                if (board.isSquareOnBoard((hunted1.getX() + 1), hunted1.getY())) {
                    hunted2 = new Coordinate((hunted1.getX() + 1), (hunted1.getY()));
                    if (board.getSquareStatus(hunted2) == 1)  // 1 == shootable
                        stat = board.shoot(hunted2);
                    else
                        ChangeDirection(board);  // shot earlier -> try another direction
                    break a;
                } else {
                    ChangeDirection(board);  // square outside of the board -> try another direction
                    break a;
                }
            }
            if (hunted2.getX() == hunted1.getX() + 1)
                if (board.isSquareOnBoard((hunted1.getX() + 2), hunted1.getY())) {
                    hunted2 = new Coordinate((hunted1.getX() + 2), (hunted1.getY()));
                    if (board.getSquareStatus(hunted2) == 1)
                        stat = board.shoot(hunted2);
                    else
                        ChangeDirection(board); // shot earlier -> try another direction
                    break a;
                } else {
                    ChangeDirection(board); // square outside of the board -> try another direction
                    break a;
                }

            if (hunted2.getX() == (hunted1.getX() + 2))
                if (board.isSquareOnBoard((hunted1.getX() + 3), hunted1.getY())) {
                    hunted2 = new Coordinate((hunted1.getX() + 3), (hunted1.getY()));
                    if (board.getSquareStatus(hunted2) == 1)
                        stat = board.shoot(hunted2);
                    else
                        ChangeDirection(board); // shot earlier -> try another direction
                    break a;
                } else {
                    ChangeDirection(board); // square outside of the board -> try another direction
                    break a;
                }
        }   //  end a:

        // North is next direction        
        b:
        if (direction == 2) {
            if (hunted2.getX() == -1)
                if (board.isSquareOnBoard((hunted1.getX() - 1), hunted1.getY())) {
                    hunted2 = new Coordinate((hunted1.getX() - 1), (hunted1.getY()));
                    if (board.getSquareStatus(hunted2) == 1)
                        stat = board.shoot(hunted2);
                    else
                        ChangeDirection(board); // shot earlier -> try another direction
                    break b;
                } else {
                    ChangeDirection(board); // square outside of the board -> try another direction
                    break b;
                }

            if (hunted2.getX() == hunted1.getX() - 1)
                if (board.isSquareOnBoard((hunted1.getX() - 2), hunted1.getY())) {
                    hunted2 = new Coordinate((hunted1.getX() - 2), (hunted1.getY()));
                    if (board.getSquareStatus(hunted2) == 1)
                        stat = board.shoot(hunted2);
                    else
                        ChangeDirection(board); // shot earlier -> try another direction
                    break b;
                } else {
                    ChangeDirection(board); // square outside of the board -> try another direction
                    break b;
                }

            if (hunted2.getX() == (hunted1.getX() - 2))
                if (board.isSquareOnBoard((hunted1.getX() - 3), hunted1.getY())) {
                    hunted2 = new Coordinate((hunted1.getX() - 3), (hunted1.getY()));
                    if (board.getSquareStatus(hunted2) == 1)
                        stat = board.shoot(hunted2);  // last shot at east: sunk or missed
                    else
                        ChangeDirection(board); // shot earlier -> try another direction
                    break b;
                } else {
                    ChangeDirection(board); // square outside of the board -> try another direction
                    break b;
                }
        }  // end b

        // West is next direction        
        c:
        if (direction == 3) {
            if (hunted2.getY() == -1)
                if (board.isSquareOnBoard((hunted1.getX()), hunted1.getY() - 1)) {
                    hunted2 = new Coordinate((hunted1.getX()), (hunted1.getY() - 1));
                    if (board.getSquareStatus(hunted2) == 1)
                        stat = board.shoot(hunted2);
                    else
                        ChangeDirection(board); // shot earlier -> try another direction
                    break c;
                } else {
                    ChangeDirection(board); // square outside of the board -> try another direction
                    break c;
                }

            if (hunted2.getY() == hunted1.getY() - 1)
                if (board.isSquareOnBoard((hunted1.getX()), hunted1.getY() - 2)) {
                    hunted2 = new Coordinate((hunted1.getX()), (hunted1.getY() - 2));
                    if (board.getSquareStatus(hunted2) == 1)
                        stat = board.shoot(hunted2);
                    else
                        ChangeDirection(board); // shot earlier -> try another direction
                    break c;
                } else {
                    ChangeDirection(board); // square outside of the board -> try another direction
                    break c;
                }

            if (hunted2.getY() == (hunted1.getY() - 2))
                if (board.isSquareOnBoard((hunted1.getX()), hunted1.getY() - 3)) {
                    hunted2 = new Coordinate((hunted1.getX()), (hunted1.getY() - 3));
                    if (board.getSquareStatus(hunted2) == 1)
                        stat = board.shoot(hunted2);  // last shot at east: sunk or missed
                    else
                        ChangeDirection(board); // shot earlier -> try another direction
                    break c;
                } else {
                    ChangeDirection(board); // square outside of the board -> try another direction
                    break c;
                }
        }  // c

        // East is last direction
        d:
        if (direction == 4) {
            if (hunted2.getY() == -1)
                if (board.isSquareOnBoard((hunted1.getX()), hunted1.getY() + 1)) {
                    hunted2 = new Coordinate((hunted1.getX()), (hunted1.getY() + 1));
                    if (board.getSquareStatus(hunted2) == 1)
                        stat = board.shoot(hunted2);
                    else
                        ChangeDirection(board); // shot earlier -> try another direction
                    break d;
                } else {
                    ChangeDirection(board); // square outside of the board -> try another direction
                    break d;
                }

            if (hunted2.getY() == hunted1.getY() + 1)
                if (board.isSquareOnBoard((hunted1.getX()), hunted1.getY() + 2)) {
                    hunted2 = new Coordinate((hunted1.getX()), (hunted1.getY() + 2));
                    if (board.getSquareStatus(hunted2) == 1)
                        stat = board.shoot(hunted2);
                    else
                        ChangeDirection(board); // shot earlier -> try another direction
                    break d;
                } else {
                    ChangeDirection(board); // square outside of the board -> try another direction
                    break d;
                }

            if (hunted2.getY() == (hunted1.getY() + 2))
                if (board.isSquareOnBoard((hunted1.getX()), hunted1.getY() + 3)) {
                    hunted2 = new Coordinate((hunted1.getX()), (hunted1.getY() + 3));
                    if (board.getSquareStatus(hunted2) == 1)
                        stat = board.shoot(hunted2);
                    else
                        ChangeDirection(board); // shot earlier -> try another direction
                    break d;
                } else {
                    ChangeDirection(board); // square outside of the board -> try another direction
                    break d;
                }
        }  // d

        // if missed -> next round there had to be a new direction
        if (stat == 2)
            ChangeDirection(board);

        return stat;
    }

    /**
     * Goes around a ship until finds shootable a square.
     *
     * @param board computer shoots at HumanBoard.
     */
    protected void ChangeDirection(HumanBoard board) {
        Coordinate tmp;
        n:
        if (direction != 0) {
            if (direction == 1) {
                direction++;
                if (board.isSquareOnBoard((hunted1.getX() - 1), hunted1.getY())) {
                    tmp = new Coordinate((hunted1.getX() - 1), hunted1.getY());
                    if (board.getSquareStatus(tmp) == 1)
                        hunted2 = new Coordinate(-1, -1);
                    else ChangeDirection(board);
                } else ChangeDirection(board);
                break n;
            } else if (direction == 2) {
                direction++;
                if (board.isSquareOnBoard((hunted1.getX()), hunted1.getY() - 1)) {
                    tmp = new Coordinate((hunted1.getX()), hunted1.getY() - 1);
                    if (board.getSquareStatus(tmp) == 1)
                        hunted2 = new Coordinate(-1, -1);
                    else ChangeDirection(board);
                } else ChangeDirection(board);
                break n;
            } else if (direction == 3) {
                direction++;
                if (board.isSquareOnBoard((hunted1.getX()), hunted1.getY() + 1)) {
                    tmp = new Coordinate((hunted1.getX()), hunted1.getY() + 1);
                    if (board.getSquareStatus(tmp) == 1)
                        hunted2 = new Coordinate(-1, -1);
                    else ChangeDirection(board);
                } else ChangeDirection(board);
                break n;
            }
        }
    }

}  
