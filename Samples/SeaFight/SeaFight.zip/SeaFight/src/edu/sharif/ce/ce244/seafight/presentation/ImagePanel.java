package edu.sharif.ce.ce244.seafight.presentation;

import javax.swing.*;
import java.awt.*;

/**
 * ImagePanel draw an image for new panel
 * 
 * @author Kallio, Leisma, Tammivuori 
 * @version 220503
 */
class ImagePanel extends JPanel {
    Image image;

    /**
     * Parameterized constructor.
     * @param image image that we want to show
     */
    public ImagePanel(Image image) {
        this.image = image;

    }
    
    /**
     * Parameterized constructor.
     * @param g needed graphics     
     */
    public void paintComponent(Graphics g) {
       super.paintComponent(g); //paint background

        //Draw image at its natural size
        g.drawImage(image, 0, 0, this); //85x62 image

    }
}
