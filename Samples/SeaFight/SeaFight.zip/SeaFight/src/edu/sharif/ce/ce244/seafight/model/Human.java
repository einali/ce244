package edu.sharif.ce.ce244.seafight.model;

import edu.sharif.ce.ce244.seafight.presentation.DisplayContainer;
import edu.sharif.ce.ce244.seafight.presentation.board.Gameboard;
import edu.sharif.ce.ce244.seafight.presentation.board.MachineBoard;

/**
 * Extends abstract class Player. Contains methods for the humanplayer to place ships
 * on gameboard.
 *
 * @author Kallio, Leisma, Tammivuori
 * @version (200503)
 */
public class Human extends Player {

    public static boolean turn = false;

    private Ship currentShip;
    private int i = 1;

    /**
     * Constructor for objects of class Human. Initialise instance variables.
     */
    public Human(DisplayContainer DisplayContainer) {
        this.name = "Player";
        this.displayContainer = DisplayContainer;
        this.currentShip = new Ship(4, OrientationType.North, DisplayContainer); // 4 = Ship size (1..4), 1 = direction (1..4)
    }

    /**
     * Sets player name
     *
     * @param name player's name is palyer i.e. type Human
     */
    public void setPlayerName(String name) {
        this.name = name;
    }

    /**
     * Reveals player name
     *
     * @return name "player" i.e. type Human
     */
    public String getPlayerName() {
        return this.name;
    }

    /**
     * Sets pause of chosen time limit
     *
     * @param x time of the pause
     */
    public void pause(int x) {
        try {
            Thread.sleep(x);
        } catch (InterruptedException e) {
        }
    }


    /**
     * Humanplayer clicks on a square in opponents gameboard, MyMouseListner takes care of
     * action i.e. change turn.
     *
     * @return turn shows if turn was played succesfully
     */
    public boolean playTurn(MachineBoard board) {
        pause(800);
        return turn;
    }

    /**
     * Reveals the ship that is currenttly dealed with
     *
     * @return ship contains size and direction.
     */
    public Ship getCurrentShip() {
        return this.currentShip;
    }

    /**
     * Humanplayer places ships on gameboard by pointing and clicking with mouse. Placing starts
     * from the biggest ship. Ship's orientation can be changed.
     *
     * @return true if there is still ships left to place, false if all ships have been placed
     */
    public boolean setCurrentShip(Gameboard board) {

        if (i < 3) { // 2 x Ship size 3
            currentShip = new Ship(3, OrientationType.North, displayContainer);
            displayContainer.showSize(3);
            board.changeCursor(CursorType.findByShipOrientation(currentShip.getShipOrientation()));
            i++;
            return true;
        }

        if (i < 6) { // 3 x Ship size 2
            currentShip = new Ship(2, OrientationType.North, displayContainer);
            displayContainer.showSize(2);
            board.changeCursor(CursorType.findByShipOrientation(currentShip.getShipOrientation()));
            i++;
            return true;
        }

        if (i < 10) { // 4 x Ship size 1
            currentShip = new Ship(1, OrientationType.North, displayContainer);
            displayContainer.showSize(1);
            board.changeCursor(CursorType.findByShipOrientation(currentShip.getShipOrientation()));
            i++;
            return true;
        }

        // clear buttons and statuses after placing
        board.buttonmatrixCleanButtons();
        board.clearAllHitStatus();
        board.changeCursor(null); // back to default Cursor after placing Ships

        currentShip = null;

        // only get this far when no more ships left to place
        return false;
    }

}
    

