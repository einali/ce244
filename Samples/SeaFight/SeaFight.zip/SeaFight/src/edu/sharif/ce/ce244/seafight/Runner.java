package edu.sharif.ce.ce244.seafight;

import edu.sharif.ce.ce244.seafight.presentation.SeaFight;

import java.awt.*;

/**
 * Created by Teaching on 10/23/2015.
 */
public class Runner {
    public static void main(String[] args) {
        Frame frame = new Frame();
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent e) {
                System.exit(0);
            }

            ;
        });

        SeaFight seaFight = new SeaFight();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int width = (int) (screenSize.getWidth() * 0.9);
        int height = (int) (screenSize.getHeight() * 0.9);


        seaFight.setSize(width, height);
        seaFight.setSize(width, height);
        frame.add(seaFight);
        frame.pack();
        seaFight.start();
        frame.setSize(width, height + 20); // add 20, seems enough for the Frame title,
        frame.setVisible(true);
    }
}
