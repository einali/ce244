package edu.sharif.ce.ce244.seafight.presentation;

import edu.sharif.ce.ce244.seafight.model.Game;
import edu.sharif.ce.ce244.seafight.model.Human;
import edu.sharif.ce.ce244.seafight.model.Machine;
import edu.sharif.ce.ce244.seafight.presentation.board.HumanBoard;
import edu.sharif.ce.ce244.seafight.presentation.board.MachineBoard;
import edu.sharif.ce.ce244.seafight.util.Utils;

import javax.sound.sampled.Clip;
import javax.swing.*;
import java.awt.*;

/**
 * Seaflight is a core of a game. It draws basic applet and calls other objects.
 * Game is a one player fight, where the opponent is computer. Both parties try to
 * sink anothers ships. Which one has sunked all other ships earlies is winner.
 *
 * @author Kallio, Leisma, Tammivuori
 * @version 220503
 */
public class SeaFight extends JPanel implements DisplayContainer,Game {

    /**
     * needs only one human player
     */
    private   Human player;

    /**
     * needs only one computer player
     */
    private   Machine opponent;

    /**
     * field where is game's name
     */
    private JLabel headerField;

    /**
     * field where is humanplayer
     */
    private JLabel humanField;

    /**
     * field where is computerplayer
     */
    private JLabel computerField;

    /**
     * humanplayer's gameboard
     */
    public  HumanBoard humanBoard;

    /**
     * computer's gameboard
     */
    private MachineBoard machineBoard;

    /**
     * Starting dialog
     */
    public  JPanel dialog;

    /**
     * field which shows messages for player
     */
    private  JTextArea messageField;

    /**
     * panel where is a ship image
     */
      JPanel shipPanel;

    /**
     * shows the orientation of current placing ship
     */
    private JTextField orientationField;

    /**
     * shows the size of current placing ship
     */
    private JTextField sizeField;



    /**
     * shows if players are playing game
     * if not  player is placing ships \
     */
    private boolean playingGame;

    private boolean gameIsOver;

    /**
     * shows the winner
     */
    public  String winner = "";


    /**
     * Initializer for objects of class Seafight
     */
    public SeaFight() {
        setLayout(new BorderLayout());

        // shows starting dialog
        dialog = this;

        setPlayingGame(false);
        setGameIsOver(false);

        // headers
        JPanel headers = new JPanel();
        headers.setLayout(new BorderLayout());
        this.add("North", headers);

        // gameboards
        JPanel boards = new JPanel();
        boards.setLayout(new BorderLayout());
        this.add("Center", boards);

        // message area at the bottom
        messageField = new JTextArea(" ", 5, 10);
        messageField.setEditable(false);
        // new font for a messagefield. Font size is little bit bigger
        Font currentFont = messageField.getFont();
        String fname = currentFont.getName();
        int fstyle = currentFont.getStyle();
        Font font = new Font(fname, fstyle, 16);
        messageField.setFont(font);
        messageField.setBackground(Color.lightGray);

        // messages
        JScrollPane messages = new JScrollPane(messageField);
        messages.setLayout(new ScrollPaneLayout());
        this.add("South", messages);

        // create Players
        player = new Human(this);
        opponent = new Machine(this,this);

        // header and names at the top
        headerField = new JLabel("The SeaFight Game", JLabel.CENTER);
        headers.add("North", headerField);

        computerField = new JLabel(opponent.getPlayerName());
        headers.add("West", computerField);

        humanField = new JLabel(player.getPlayerName());
        headers.add("East", humanField);

        // gameboards and shipfield at the center
        // shipfield
        shipPanel = new JPanel();
        shipPanel.setLayout(new BorderLayout());
        boards.add("Center", shipPanel);

        Image image = Utils.getImage("ships.jpg");
        ImagePanel imagePanel = new ImagePanel(image);
        shipPanel.add(imagePanel);

        orientationField = new JTextField("West", 10);
        orientationField.setEditable(false);
        shipPanel.add("North", orientationField);
        sizeField = new JTextField("Ship size: 4", 10);
        sizeField.setEditable(false);
        shipPanel.add("South", sizeField);

        // gameboards
        humanBoard = new HumanBoard(player, this);
        boards.add("East", humanBoard);
        machineBoard = new MachineBoard(opponent, this);
        machineBoard.setSize(10, 10);
        boards.add("West", machineBoard);

    }


    /**
     * Start only shows initial info and help messages
     */
    public void start() {


        try {
            Clip oceanClip = Utils.getClip("Oceansea.wav");

            Clip battleClip = Utils.getClip("Battle3.wav");

            Clip explo1Clip = Utils.getClip("Explosi1.wav");


            battleClip.loop(1000);
            oceanClip.loop(1000);
            explo1Clip.start();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //show messages and instructions
        JOptionPane.showMessageDialog(dialog,
                "Welcome to play SeaFight!! \n " +
                        "- You are playing against the computer. \n" +
                        "Please place your ships on the gameboard with the title Player.\n " +
                        "You can rotate them (before placing) by right-clicking and drop\n" +
                        "then in the coordinate matrix by left-clicking the mouse.\n",
                "SeaFight Game info",
                JOptionPane.PLAIN_MESSAGE,
                new ImageIcon(Utils.getImage("ships.jpg"))
        );

    }

    /**
     * Shows messages in the messageField.
     *
     * @param message message which will be displayed in the messageField
     */
    @Override
    public void showMessage(String message) {
        messageField.selectAll();
        messageField.replaceSelection(message);
    }

    /**
     * Displays ship's orientation in orientationField.
     *
     * @param message tells ship orientation
     */
    @Override
    public void showOrientation(String message) {
        orientationField.setText(message);
    }

    /**
     * Displays ship size in sizeField
     *
     * @param size size of ship
     */
    @Override
    public void showSize(int size) {
        sizeField.setText("Ship size: " + size);
    }


    /**
     * Sets game status to be playing game
     */
    @Override
    public void setPlayingGame(boolean playing) {
        this.playingGame=playing;

    }

    /**
     * Sets game over after all either's ships has sunked
     */
    @Override
    public void setGameOver() {
        playingGame = false;
        JOptionPane.showMessageDialog(dialog, "Game over. " + winner,
                "SeaFight Game Over info",
                JOptionPane.PLAIN_MESSAGE
        );
        setGameIsOver(true);
    }


    /**
     * Returns information if players are playing game
     *
     * @return true if players are playing game, else returns false
     */
    @Override
    public boolean getPlayingGame() {
        return playingGame;
    }

    @Override
    public boolean isGameIsOver() {
        return gameIsOver;
    }

    @Override
    public void setGameIsOver(boolean gameIsOver) {
        this.gameIsOver = gameIsOver;
    }

    public void setShipPanelVisible(){
        this.shipPanel.setVisible(true);
    }

    public MachineBoard getMachineBoard() {
        return machineBoard;
    }

    public Human getPlayer() {
        return player;
    }

    public void makeOpponentPlay() {
        opponent.playTurn(humanBoard);
    }

    public HumanBoard getHumanBoard() {
        return humanBoard;
    }

    public void setWinner(String winner) {
        this.winner = winner;
    }
}

