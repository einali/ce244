package edu.sharif.ce.ce244.seafight.model;

/**
 * Created by Teaching on 10/23/2015.
 */
public interface Game {

    void setPlayingGame(boolean playing);

    void setGameOver();

    boolean getPlayingGame();

    boolean isGameIsOver();

    void setGameIsOver(boolean gameIsOver);
}
