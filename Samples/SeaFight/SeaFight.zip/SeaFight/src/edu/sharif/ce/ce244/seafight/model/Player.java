package edu.sharif.ce.ce244.seafight.model;

import edu.sharif.ce.ce244.seafight.presentation.DisplayContainer;
import edu.sharif.ce.ce244.seafight.presentation.board.Gameboard;

/**
 * Abstract class, initialize methods for classes Human and Machine.
 * 
 * @author Kallio, Leisma, Tammivuori 
 * 
 * @version(200503)
 * 
 */

public abstract class Player
{
    protected String name;
    protected DisplayContainer displayContainer;
    protected Game game;


/**
* sets Players name
*/
    abstract void setPlayerName(String name);
/**
* get Players name
*/
    abstract String getPlayerName();

/**
* get the current Ship (when placing Ships)
*/
    abstract public Ship getCurrentShip();

/**
* sets current edu.sharif.ce.ce244.seafight.model.Ship
*/
    abstract public boolean setCurrentShip(Gameboard board);
}
   
