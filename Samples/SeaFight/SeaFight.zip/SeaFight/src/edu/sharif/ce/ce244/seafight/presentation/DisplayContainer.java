package edu.sharif.ce.ce244.seafight.presentation;

/**
 * Created by Teaching on 10/23/2015.
 */
public interface DisplayContainer {
    void showMessage(String message);

    void showOrientation(String message);

    void showSize(int size);
}
