package edu.sharif.ce.ce244.seafight.model;

/**
 * Created by Teaching on 10/23/2015.
 */
public enum CursorType {
    DefaultCursor, ShootCursor, ShipCursorNorth, ShipCursorEast, ShipCursorSouth, ShipCursorWest;

    public static CursorType findByShipOrientation(OrientationType shipOrientationType) {
        switch (shipOrientationType) {
            case North:
                return ShipCursorNorth;
            case East:
                return ShipCursorEast;
            case South:
                return ShipCursorSouth;
            case West:
                return ShipCursorWest;
            default:
                return DefaultCursor;
        }
    }
}
