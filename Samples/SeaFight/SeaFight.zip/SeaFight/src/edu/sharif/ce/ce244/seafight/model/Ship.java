package edu.sharif.ce.ce244.seafight.model;

import edu.sharif.ce.ce244.seafight.presentation.DisplayContainer;

/**
 * Ships, which are sinked during the game
 *
 * @author Kallio, Leisma, Tammivuori
 * @version 220503
 */
public class Ship {
    private final DisplayContainer displayContainer;
    /**
     * ship's size. Can be 1, 2, 3 or 4
     */
    private int size;

    /**
     * ship's oritentation: 1=North, 2=East, 3=South, 4=West
     */
    private OrientationType orientation;

    /**
     * record of coordinates where ship is placed
     * first value is the basepoint for positioning and rotation
     */
    private Coordinate[] occupiedSquares;

    /**
     * shows which part of ship is hitted. Needed when check sinking.
     */
    private int[] hits; //0=notHit 1=Hit


    /**
     * Parameterized constructor.
     *
     * @param size        ship's size
     * @param orientation ship's orientation
     */
    public Ship(int size, OrientationType orientation, DisplayContainer DisplayContainer) {
        this.size = size;
        this.orientation = orientation;
        this.displayContainer = DisplayContainer;
        hits = new int[size];
        occupiedSquares = new Coordinate[size];
        for (int i = 0; i < size; i++) {
            occupiedSquares[i] = new Coordinate();
            hits[i] = 0;
        }
    }

    /**
     * Returns ship size.
     *
     * @return size of ship
     */
    public int getShipSize() {
        return this.size;
    }

    /**
     * Returns ship orientation.
     *
     * @return orientation of ship
     */
    public OrientationType getShipOrientation() {
        return this.orientation;
    }

    /**
     * Returns place where one part of ship is.
     *
     * @param index index of occupiedSquares array.
     * @return coordinate from given index
     */
    public Coordinate getShipCoordinate(int index) {
        return this.occupiedSquares[index];
    }

    /**
     * Sets coordinate of ship's place.
     *
     * @param index index where place will be marked
     * @param xy    place
     */
    public void setShipCoordinate(int index, Coordinate xy) {
        this.occupiedSquares[index].setCoordinate(xy);
    }

    /**
     * Sets ship hitted.
     *
     * @param xy place which was shooted
     */
    public void setShipHitStatus(Coordinate xy) {
        int x = xy.getX();
        int y = xy.getY();
        for (int i = 0; i < size; i++) {
            if ((occupiedSquares[i].getX() == x) &&
                    (occupiedSquares[i].getY() == y))
                hits[i] = 1;
        }
    }

    /**
     * Set a new orientation for a ship.
     *
     * @param orientation new orientation
     */
    public void setShipOrientation(OrientationType orientation) {
        this.orientation = orientation;
    }

    /**
     * Checks has ship sunk already
     *
     * @return true if ship has sunk, else returns false
     */
    public boolean hasShipSunk() {
        for (int i = 0; i < size; i++) {
            if (hits[i] == 0) { // 0=notHit 1=Hit
                return false;
            }
        }
        return true;
    }

    /**
     * Rotates the ship 90 degrees clockwise
     */
    public void rotate() {
        this.orientation = this.orientation.rotate();// pay attention: all enums are immutable
        displayContainer.showOrientation(this.orientation.getMessage());
    }

}

