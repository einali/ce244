package edu.sharif.ce.ce244.seafight.model;

/**
 * Coordinate shows places on the gameboard.
 *  
 * @author Kallio, Leisma, Tammivuori 
 * @version 220503
 */
public class Coordinate {
    /**
     * x coordinate
     */
    private int x;

    /**
     * y coordinate
     */
    private int y;  

    /**
     * Default constructor creates coordinate to default place (-1, -1).
     */
    public Coordinate() {
        this.x = -1;
        this.y = -1;     
    }

    /**
     * Parameterized constructor
     * @param int x: x coordinate
     * @param int y: y coordinate     
     */
    public Coordinate(int x, int y) {
        this.x = x;
        this.y = y;     
    }

    /**
     * Parameterized constructor
     * @param Coordinate xy: object of class Coordinate
     */
    public Coordinate(Coordinate xy) {
        this.x = xy.getX();
        this.y = xy.getY();
    }

    /**
     * Sets new coordinates
     * @param x new x coordinate
     * @param y new y coordinate
     */  
    public void setCoordinate(int x, int y) {
        this.x = x;
        this.y = y;     
    }

    /**
     * Sets new coordinates
     * @param xy new coordinate xy
     */  
    public void setCoordinate(Coordinate xy) {
        this.x = xy.getX();
        this.y = xy.getY();
    }

    /**
     * Returns x coordinate
     * @return x coordinate
     */    
    public int getX(){
        return this.x;
    }

    /**
     * Returns y coordinate
     * @return y coordinate
     */  
    public int getY(){
        return this.y;
    }

}
