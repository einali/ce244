package edu.sharif.ce.ce244.seafight.util;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Random;

/**
 * Created by Teaching on 10/23/2015.
 */
public class Utils {

    private static String resourceFolderLocation = "resources";

    public static Image getImage(String path) {

        File sourceimage = new File(resourceFolderLocation + File.separator + path);
        try {
            Image image = ImageIO.read(sourceimage);
            return image;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Clip getClip(String path) throws Exception {
        Clip clip = AudioSystem.getClip();
        AudioInputStream inputStream = AudioSystem.getAudioInputStream(new File(resourceFolderLocation + File.separator + path));
        clip.open(inputStream);
        return clip;
    }

    /**
     * Generate new random number, which is smaller than given number
     *
     * @param number upper limit for a number
     * @return random number
     */
    public static int getRandom(int number) {
        Random sat = new Random();
        boolean exit = false;
        int tulos = (int) (Math.abs(sat.nextInt() % number));
        return tulos;
    }

}
